class MyCylinderWTop extends CGFobject
{
	
	constructor(scene, slices, stacks)
     {
       super(scene);
       this.slices = slices;
       this.stacks = stacks;

       this.initBuffers();

       this.display();
     }

	initBuffers()  
	{
		this.vertices = [];

		this.indices = [];

		this.primitiveType = this.scene.gl.TRIANGLES;
		
		this.normals = [];

		this.texCoords = [];
		        
        var angle = 2*3.14159/this.slices;
        var r = 1;
        var h = 1;

        var angleNormal = angle/2;
       	var count = 0;
        var j = 0;          

        
        var stack_size = 1/this.stacks;


        for ( var w = 0; w < this.stacks; w++)
        {
        	 
			for (var i = 0; i < this.slices; i++)
			{ 

			  
			   this.vertices.push(Math.cos(angle * i), Math.sin(angle * i), (w+1)*stack_size);
			   this.vertices.push(Math.cos(angle * i), Math.sin(angle * i),w*stack_size);
			   this.vertices.push(Math.cos(angle * (i+1)), Math.sin(angle * (i+1)),w*stack_size);
			   this.vertices.push(Math.cos(angle * (i+1)), Math.sin(angle * (i+1)),(w+1)*stack_size);


				this.indices.push(j, j + 1, j + 2); // 012
				this.indices.push(j+2, j+1, j); 
				this.indices.push(j, j + 2, j + 3); // 023
				this.indices.push(j+3, j+2, j);
				j = j + 4;

				this.normals.push(Math.cos(angle*i) , Math.sin(angle*i),0);
				this.normals.push(Math.cos(angle*i) , Math.sin(angle*i),0);
				this.normals.push(Math.cos(angle*(i+1)) , Math.sin(angle*(i+1)),0);
				this.normals.push(Math.cos(angle*(i+1) ), Math.sin(angle*(i+1)),0);

                this.texCoords.push(0,0);
                this.texCoords.push(0,0);
                this.texCoords.push(0,0);
                this.texCoords.push(0,0);
			}

        }
        

        for(var i = 0; i < this.slices; i++)
        {
            this.vertices.push(Math.cos(angle*i),Math.sin(angle * i), 1);
			this.texCoords.push( (Math.cos(angle*i) + 1)/2,(-Math.sin(angle*i) + 1)/2); 
        }
        
        this.vertices.push(0,0,1);
        this.texCoords.push(0.5,0.5);
        
        
        for(var i = 1; i < this.slices; i++)
        {
            this.indices.push(j,j+1 ,this.vertices.size); 
            j = j + 1;
        }


        for(var i = 0; i < this.slices; i++)
        {
            this.normals.push(0, 0, 1); 
        }
        
        this.normals.push(0,0,1);

        console.log(this.vertices);
        console.log(this.texCoords);
        console.log(this.normals);
        console.log(this.indices);
        
        
		this.initGLBuffers();
	};
};
